class Obstacle extends ElementPartie {
  constructor(ctrl, texture, points, vitesse) {
    super(ctrl, texture, points, vitesse);
  }

  update(){
    super.update();
  }
}
