class Piece extends ElementPartie {
  constructor(ctrl, points, vitesse) {
    super(ctrl,"Coin_1.png", points, vitesse);
  }
}
