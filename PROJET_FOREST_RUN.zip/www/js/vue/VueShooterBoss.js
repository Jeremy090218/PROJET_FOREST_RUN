class VueShooterBoss extends VueJeu {
  constructor(ctrl) {
    super(ctrl, 'shooterBoss');
  }
}
