class VueShooterEchec extends VueJeu {
  constructor(ctrl) {
    super(ctrl, 'shooterEchec');
  }
}
