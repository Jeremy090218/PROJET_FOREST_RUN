class Obstacle extends ElementPartie {
  constructor(ctrl, points, vitesse) {
    super(ctrl, "Obstacle_1.png", points, vitesse);
  }

  update(){
    super.update();
  }
}
