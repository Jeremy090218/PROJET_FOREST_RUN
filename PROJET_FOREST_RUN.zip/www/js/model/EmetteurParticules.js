class EmetteurParticules extends Element {
  constructor(ctrl, nb, temps, texture, x, y, z) {
    super(ctrl, texture x, y, z);

    this.particules = new Array();
    this.dt = temps / nb;
    this.nb = nb;
    this.tempsActuel = 0;
  }

  getParticules(){
    return this.particules;
  }

  update(){
    if(this.tempsActuel%this.dt == 0) {
      this.particules.push({x: this.getX(), y: this.getY(), z: this.getZ()});
    }
  }
}
