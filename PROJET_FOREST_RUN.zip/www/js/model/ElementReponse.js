class FioleBleu extends ElementPartie {
  constructor(ctrl, points, vitesse) {
    super(ctrl,"potionBleu.png", points, vitesse);
  }
}

class FioleRouge extends ElementPartie {
  constructor(ctrl, points, vitesse) {
    super(ctrl,"potionRouge.png", points, vitesse);
  }
}
