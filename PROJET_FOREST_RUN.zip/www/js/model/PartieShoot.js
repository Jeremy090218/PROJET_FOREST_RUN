class PartieShoot extends Partie {
  constructor(ctrl, personnage, questions) {
    super(ctrl, personnage, questions);
  }
}
