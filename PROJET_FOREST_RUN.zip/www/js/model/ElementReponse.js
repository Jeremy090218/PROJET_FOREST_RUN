class ElementReponse extends ElementPartie {
  constructor(ctrl, texture, points, vitesse){
    super(ctrl, texture, points, vitesse);
  }
}
